namespace MvcMovieDesktop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            dataGridViewMovies = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewMovies).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewMovies
            // 
            dataGridViewMovies.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewMovies.Location = new Point(422, 120);
            dataGridViewMovies.Name = "dataGridViewMovies";
            dataGridViewMovies.Size = new Size(240, 150);
            dataGridViewMovies.TabIndex = 0;
            // 
            // Form1
            // 
            ClientSize = new Size(847, 492);
            Controls.Add(dataGridViewMovies);
            Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridViewMovies).EndInit();
            ResumeLayout(false);
        }
    }
}
