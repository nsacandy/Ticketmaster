
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;
using MvcMovie.Data;

namespace MvcMovieDesktop


{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            var config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();

            // Step 2: Get the connection string from the configuration
            var connectionString = config.GetConnectionString("MvcMovieContext");

            // Step 3: Set up the DbContext with the connection string
            var optionsBuilder = new DbContextOptionsBuilder<MvcMovieContext>();
            optionsBuilder.UseSqlServer(connectionString);

            // Step 4: Create the DbContext instance
            var dbContext = new MvcMovieContext(optionsBuilder.Options);

            // Example: Retrieve and display movies
            var movies = dbContext.Movie.ToListAsync().Result;
            foreach (var movie in movies)
            {
                Console.WriteLine($"Title: {movie.Title}, Genre: {movie.Genre}");
            }

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}