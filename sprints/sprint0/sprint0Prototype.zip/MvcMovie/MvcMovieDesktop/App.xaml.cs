﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using MvcMovieDesktop.Data;
using System.IO;
using MvcMovie.Data;
using System.Windows;

namespace MvcMovieDesktop
{
    public partial class App : Application
    {
        public static IConfiguration Configuration { get; private set; }

        public App()
        {
            InitializeComponent();

            // Set up configuration to read from appsettings.json
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())  // Or specify the directory path if needed
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            Configuration = builder.Build();
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Now, you can pass the connection string into DbContext
            var options = new DbContextOptionsBuilder<MvcMovieContext>()
                .UseSqlServer(Configuration.GetConnectionString("MvcMovieContext"))
                .Options;

            var context = new MvcMovieContext(options);
            // Now you can work with your context
        }
    }
}