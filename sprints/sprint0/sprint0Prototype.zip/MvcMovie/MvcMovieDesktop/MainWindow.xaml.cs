﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.EntityFrameworkCore;
using MvcMovieDesktop.Data;
using MvcMovie.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using MvcMovieDesktop.Data;
using System.IO;

namespace MvcMovieDesktop
{
    public partial class MainWindow : Window
    {
        private readonly MvcMovieContext _context;

        // Constructor for MainWindow
        public MainWindow()
        {
            InitializeComponent();

            // Get the configuration from App.xaml.cs (already loaded with the connection string)
            var options = new DbContextOptionsBuilder<MvcMovieContext>()
                .UseSqlServer(App.Configuration.GetConnectionString("MvcMovieContext"))
                .Options;

            // Initialize the DbContext
            _context = new MvcMovieContext(options);

            // Example: load some movies when the window is initialized
            LoadMovies();
        }

        // Example of a method to load movies from the database
        private async void LoadMovies()
        {
            try
            {
                var movies = await _context.Movie.ToListAsync();
                MoviesListBox.ItemsSource = movies.Select(m => m.Title).ToList();  // Bind movie titles to ListBox
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading movies: {ex.Message}");
            }
        }
    }
}