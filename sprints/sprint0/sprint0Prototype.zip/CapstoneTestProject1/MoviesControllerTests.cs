﻿using Moq;
using Xunit;
using MvcMovie.Controllers;
using MvcMovie.Models;
using MvcMovie.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

namespace MvcMovie.Tests
{
    public class MoviesControllerTests
    {
        private readonly MoviesController _controller;
        private readonly MvcMovieContext _context;

        public MoviesControllerTests()
        {
            // Set up an in-memory database
            var options = new DbContextOptionsBuilder<MvcMovieContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase") // Unique name per test run
                .Options;

            _context = new MvcMovieContext(options);

            // Seed the database with test data
            _context.Movie.AddRange(new List<Movie>
            {
                new Movie { Id = 1, Title = "Test Movie 1", ReleaseDate = new DateTime(2021, 1, 1), Genre = "Action", Price = 9.99M },
                new Movie { Id = 2, Title = "Test Movie 2", ReleaseDate = new DateTime(2022, 5, 15), Genre = "Drama", Price = 12.50M }
            });
            _context.SaveChanges();

            // Initialize the controller with the test DbContext
            _controller = new MoviesController(_context);
        }

        [Fact]
        public async Task Index_ReturnsAllMovies()
        {
            // Act
            var result = await _controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<List<Movie>>(viewResult.ViewData.Model);
            Assert.Equal(2, model.Count); // We added 2 movies in setup
        }
    }
}